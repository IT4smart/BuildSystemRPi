#!/bin/bash
cd ../../configurationpage/ConfigPage
./ConfigPagev2
