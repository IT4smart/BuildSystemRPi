cd ../../../configurationpage/ConfigPage
./ConfigPagev2

