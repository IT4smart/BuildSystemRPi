#!/bin/bash
cd /opt/IT4S/configurationpage/ConfigPage && ./ConfigPage

