#!/bin/bash
cd /opt/IT4S/ConfigPage/ConfigPage && ./ConfigPage

