#!/bin/bash
/usr/bin/xfreerdp /cert-ignore /f /u:${1} /p:${2} /d:${3} /v:${4}

