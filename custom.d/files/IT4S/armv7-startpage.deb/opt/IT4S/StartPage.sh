#!/bin/bash
cd /opt/IT4S/startpage/StartPage && ./StartPage
