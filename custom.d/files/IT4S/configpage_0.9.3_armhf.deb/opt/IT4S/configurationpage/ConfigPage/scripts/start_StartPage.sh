
#!/bin/bash
cd ../../startpage/StartPage/
./StartPage
